A configuration system for Python applications.


